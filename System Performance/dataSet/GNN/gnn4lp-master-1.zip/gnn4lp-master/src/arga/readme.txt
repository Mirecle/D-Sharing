https://jjzhou012.github.io/blog/2020/02/16/Adversarially-regularized-graph-autoencoder-for-graph-embedding.html
https://blog.csdn.net/qq_39388410/article/details/107895198
https://arxiv.org/pdf/1802.04407v2.pdf